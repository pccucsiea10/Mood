/*******************************************************************************
 * Copyright (c) 2013 Nordic Semiconductor. All Rights Reserved.
 * 
 * The information contained herein is property of Nordic Semiconductor ASA.
 * Terms and conditions of usage are described in detail in NORDIC SEMICONDUCTOR STANDARD SOFTWARE LICENSE AGREEMENT.
 * Licensees are granted free, non-transferable use of the information. NO WARRANTY of ANY KIND is provided. 
 * This heading must NOT be removed from the file.
 ******************************************************************************/
package no.nordicsemi.android.log;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;

/**
 * The log session. This object can be created with the use of {@link Logger#newSession(Context, String, String)} and is used to append new log entries to the Master Control Panel log.
 */
public class LogSession {
	/* package */final Context context;
	/* package */final Uri sessionUri;

	/* package */LogSession(final Context context, final Uri sessionUri) {
		this.context = context;
		this.sessionUri = sessionUri;
	}

	/**
	 * Returns the session {@link Uri}
	 * 
	 * @return the session Uri
	 */
	public Uri getSessionUri() {
		return sessionUri;
	}

	/**
	 * Returns the session entries {@link Uri}. New log entries may be inserted using this Uri
	 * 
	 * @return the session entries Uri
	 */
	public Uri getSessionEntriesUri() {
		return sessionUri.buildUpon().appendEncodedPath(LogContract.Log.CONTENT_DIRECTORY).build();
	}

	/**
	 * Returns the session read-only content Uri. It can be used to obtain all log entries in a single row (as a String field) with fixed syntax:<br/>
	 * f.e.:
	 * 
	 * <pre>
	 * [Application name], [Creation date]
	 * [Session name] ([Session key])
	 * D	10.34.01.124	This is the oldest log message (debug)
	 * V	10.34.02.238	This is the log message (verbose)
	 * I	10.34.03.527	This is the log message (info)
	 * W	10.34.04.812	This is the log message (warning)
	 * E	10.34.05.452	This is the log message (error)
	 * </pre>
	 * 
	 * @return the {@link Uri} that can be read using {@link ContentResolver#query(Uri, String[], String, String[], String)} method. The value will be in the first row, column number 0 (with id:
	 *         {@link LogContract.Session.Content#CONTENT})
	 */
	public Uri getSessionContentUri() {
		return sessionUri.buildUpon().appendEncodedPath(LogContract.Log.CONTENT_DIRECTORY).appendEncodedPath(LogContract.Session.Content.CONTENT).build();
	}

	@Override
	public String toString() {
		return sessionUri.toString();
	}
}
